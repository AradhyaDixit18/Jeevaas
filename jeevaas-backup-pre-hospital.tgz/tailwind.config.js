/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Deep, trustworthy navy — used for text and dark sections
        ink: {
          50: "#eef4fb",
          100: "#d9e6f4",
          200: "#b3cce9",
          300: "#7ea6d6",
          400: "#4d7cbd",
          500: "#2f5c9e",
          600: "#234a83",
          700: "#1b3a68",
          800: "#132a4d",
          900: "#0b1c36",
          950: "#071227",
        },
        // Primary healthcare blue
        brand: {
          50: "#eff9ff",
          100: "#def1ff",
          200: "#b6e4ff",
          300: "#75cfff",
          400: "#2cb6ff",
          500: "#029ff0",
          600: "#007ecd",
          700: "#0064a6",
          800: "#065589",
          900: "#0b4771",
          950: "#072d4b",
        },
        // Teal / mint accent
        teal: {
          50: "#effcf7",
          100: "#d7f7ec",
          200: "#b2eedb",
          300: "#7fdec3",
          400: "#45c6a6",
          500: "#20ac8c",
          600: "#138a72",
          700: "#116e5d",
          800: "#12574b",
          900: "#12483f",
        },
        // Restrained warm accent — used sparingly for emphasis
        warm: {
          400: "#ffb055",
          500: "#f7942f",
          600: "#e07716",
        },
      },
      fontFamily: {
        display: ["Poppins", "ui-sans-serif", "system-ui", "sans-serif"],
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 10px 40px -12px rgba(11, 28, 54, 0.18)",
        card: "0 4px 24px -8px rgba(11, 28, 54, 0.12)",
        lift: "0 24px 60px -20px rgba(11, 28, 54, 0.28)",
      },
      borderRadius: {
        "2xl": "1.25rem",
        "3xl": "1.75rem",
      },
      maxWidth: {
        content: "1200px",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "pulse-ring": {
          "0%": { transform: "scale(0.9)", opacity: "0.7" },
          "100%": { transform: "scale(1.6)", opacity: "0" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.6s ease-out both",
        float: "float 6s ease-in-out infinite",
        "pulse-ring": "pulse-ring 1.8s ease-out infinite",
      },
    },
  },
  plugins: [],
};
