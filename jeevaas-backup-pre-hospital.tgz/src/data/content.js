/**
 * ============================================================================
 *  CONTENT DATA — services, FAQs, resources, kids & wellness content
 * ============================================================================
 *  Edit copy here. Services power both the cards and the reusable detail pages.
 *  Icons are string keys resolved in src/components/Icon.js.
 * ============================================================================
 */

// --- SERVICES / TREATMENTS -------------------------------------------------
export const services = [
  {
    slug: "root-canal",
    icon: "tooth",
    title: "Root Canal Treatment",
    short: "Advanced, painless RCT that saves a damaged tooth and ends the ache.",
    image: "/services/root_canal.jpeg",
    overview:
      "A root canal treats infection deep inside a tooth so we can save it instead of removing it. Using modern rotary techniques and effective numbing, the procedure today is comfortable and usually completed in one to two visits.",
    points: [
      "Relieves severe tooth pain caused by deep decay or infection",
      "Saves your natural tooth rather than extracting it",
      "Modern rotary instruments for a smoother, faster procedure",
      "Followed by a protective crown for long-term strength",
    ],
    good_for:
      "Persistent toothache, sensitivity to hot or cold that lingers, a deep cavity, or a cracked tooth.",
  },
  {
    slug: "dental-implants",
    icon: "implant",
    title: "Dental Implants",
    short: "Permanent, natural-looking replacement for one or more missing teeth.",
    image: "/services/dental_implants.jpeg",
    overview:
      "A dental implant is a small titanium post that replaces the root of a missing tooth, topped with a custom crown. It looks, feels, and functions like a natural tooth and helps preserve the jawbone.",
    points: [
      "A fixed, long-lasting alternative to dentures or bridges",
      "Protects jawbone and keeps neighbouring teeth stable",
      "Custom-matched crown for a natural look",
      "Planned carefully with imaging for a precise fit",
    ],
    good_for: "One or more missing teeth, loose dentures, or a failing bridge.",
  },
  {
    slug: "teeth-cleaning",
    icon: "sparkle",
    title: "Teeth Cleaning & Scaling",
    short: "Professional cleaning that removes plaque and keeps gums healthy.",
    image: "/services/Teeth_cleaning.jpeg",
    overview:
      "A professional cleaning removes hardened plaque (tartar) and stains that brushing cannot reach, protecting you from gum disease and cavities. We finish with a polish for a fresh, smooth feel.",
    points: [
      "Removes tartar buildup and surface stains",
      "Helps prevent gum disease and bad breath",
      "Gentle, comfortable, and quick",
      "Recommended every six months for most people",
    ],
    good_for:
      "Routine care, bleeding or swollen gums, staining, or persistent bad breath.",
  },
  {
    slug: "braces-aligners",
    icon: "align",
    title: "Braces & Aligners",
    short: "Modern orthodontics to straighten teeth and correct the bite.",
    image: "/services/Braces.jpeg",
    overview:
      "Whether with traditional braces or near-invisible clear aligners, orthodontic treatment gradually moves teeth into a healthier, more even position. It improves both the look of your smile and how comfortably your teeth meet.",
    points: [
      "Options for children, teens, and adults",
      "Traditional braces and discreet clear-aligner choices",
      "Corrects crowding, gaps, and bite problems",
      "Straighter teeth are easier to keep clean and healthy",
    ],
    good_for: "Crowded or crooked teeth, gaps, or an uneven bite.",
  },
  {
    slug: "kids-dental",
    icon: "kids",
    title: "Kids Dental Care",
    short: "Gentle, friendly dental care that helps children love the dentist.",
    image: "/services/Kids Dental Care.jpeg",
    overview:
      "Children's teeth need special, gentle attention. Our team makes visits calm and positive, focusing on prevention, healthy habits, and treating little problems early — so your child grows up with a strong, confident smile.",
    points: [
      "Calm, child-friendly approach that reduces fear",
      "Cleanings, fluoride, and protective sealants",
      "Early guidance on brushing and healthy eating",
      "Gentle treatment of cavities and dental injuries",
    ],
    good_for:
      "First dental visits, routine check-ups, cavities, and building good habits early.",
  },
  {
    slug: "teeth-whitening",
    icon: "smile",
    title: "Teeth Whitening",
    short: "Safe, professional whitening for a brighter, confident smile.",
    image: "/services/Teeth Whitening.jpeg",
    overview:
      "Professional whitening safely lifts stains from coffee, tea, and everyday wear to brighten your smile by several shades. Done under dental supervision, it protects your gums and enamel while delivering even, natural-looking results.",
    points: [
      "Noticeably brighter smile, done safely",
      "Supervised to protect enamel and gums",
      "Even, natural-looking results",
      "Quick and comfortable",
    ],
    good_for: "Stained or dull teeth, or a refresh before an event.",
  },
];

export const getService = (slug) => services.find((s) => s.slug === slug);

// --- WHY CHOOSE US ---------------------------------------------------------
export const whyChooseUs = [
  {
    icon: "userMd",
    title: "Experienced Dental Team",
    text: "Care led by qualified dental professionals focused on getting the details right.",
  },
  {
    icon: "shield",
    title: "Painless, Modern Treatment",
    text: "Up-to-date techniques and equipment for treatment that is as comfortable as possible.",
  },
  {
    icon: "hospital",
    title: "Clean, Modern Clinic",
    text: "A hygienic, welcoming environment built around your comfort and safety.",
  },
  {
    icon: "heart",
    title: "Patient-First Approach",
    text: "Clear explanations, honest advice, and a plan built around your needs.",
  },
];

// --- FACILITIES ------------------------------------------------------------
// Kept general and honest. Add or edit as the clinic confirms specifics.
export const facilities = [
  {
    icon: "sparkle",
    title: "Modern Treatment Rooms",
    text: "Comfortable, well-equipped operatories designed for a calm experience.",
  },
  {
    icon: "shield",
    title: "Strict Sterilisation",
    text: "Careful infection-control and sterilisation protocols on every visit.",
  },
  {
    icon: "align",
    title: "Digital Dentistry",
    text: "Digital planning and imaging support for precise, predictable treatment.",
  },
  {
    icon: "kids",
    title: "Child-Friendly Space",
    text: "A gentle, reassuring setting that helps young patients feel at ease.",
  },
];

// --- PATIENT RESOURCES -----------------------------------------------------
export const patientResources = [
  {
    icon: "calendar",
    title: "Booking Your Visit",
    text: "Request an appointment online in under a minute, or call the clinic directly. Our team confirms your slot by phone.",
  },
  {
    icon: "list",
    title: "Your First Appointment",
    text: "Bring any past dental records or X-rays, a list of medicines you take, and your questions. Arrive a few minutes early for a relaxed start.",
  },
  {
    icon: "shield",
    title: "Before a Procedure",
    text: "Eat normally unless advised otherwise, and tell us about any medical conditions or allergies so we can plan safely.",
  },
  {
    icon: "heart",
    title: "After-Care",
    text: "We give clear written after-care guidance for every treatment, plus a number to call if you have any concerns.",
  },
];

// --- HEALTH & WELLNESS -----------------------------------------------------
export const healthTips = [
  {
    icon: "tooth",
    title: "Brush Twice a Day",
    text: "Two minutes, morning and night, with a fluoride toothpaste and a soft brush. Angle the brush gently towards the gum line.",
  },
  {
    icon: "sparkle",
    title: "Clean Between Teeth",
    text: "Floss or use interdental brushes once a day. It reaches the plaque a toothbrush leaves behind, where many cavities begin.",
  },
  {
    icon: "smile",
    title: "Cut Down on Sugar",
    text: "Frequent sugary snacks and drinks feed the bacteria that cause decay. Water and whole foods are kinder to teeth.",
  },
  {
    icon: "calendar",
    title: "Visit Every Six Months",
    text: "Regular check-ups catch small problems early, when they are simpler and cheaper to treat.",
  },
  {
    icon: "shield",
    title: "Protect Growing Teeth",
    text: "Sealants and fluoride help protect children's teeth. Ask us what is right for your child's age.",
  },
  {
    icon: "heart",
    title: "Don't Ignore Pain",
    text: "Toothache, bleeding gums, or sensitivity are signals worth checking. Early care usually means simpler treatment.",
  },
];

export const faqs = [
  {
    q: "How often should I have a dental check-up?",
    a: "For most people, once every six months. Your dentist may suggest a different interval based on your gum health and history.",
  },
  {
    q: "Is a root canal painful?",
    a: "Modern root canals are done with effective numbing and are usually no more uncomfortable than a routine filling. Most patients feel relief because the treatment removes the source of the pain.",
  },
  {
    q: "At what age should my child first see a dentist?",
    a: "A first visit is usually recommended by around age one, or when the first teeth appear. Early visits are short and friendly, and help children feel comfortable.",
  },
  {
    q: "How can I book an appointment?",
    a: "Use the Book Appointment form on this site, call the clinic, or message us on WhatsApp. Our team will confirm your slot by phone.",
  },
  {
    q: "Do you treat dental emergencies?",
    a: "Yes. If you have severe pain, swelling, or a knocked-out tooth, call the clinic line as early as possible so we can guide you and see you promptly.",
  },
];

// Educational disclaimer used on wellness content
export const wellnessDisclaimer =
  "This information is general dental education, not a diagnosis. For advice about your specific situation, please book a consultation.";

// --- GALLERY ---------------------------------------------------------------
// Uses real project images. Add clinic photos here as they become available.
export const gallery = [
  { src: "/services/root_canal.jpeg", alt: "Root canal treatment" },
  { src: "/services/dental_implants.jpeg", alt: "Dental implant procedure" },
  { src: "/services/Teeth_cleaning.jpeg", alt: "Professional teeth cleaning" },
  { src: "/services/Braces.jpeg", alt: "Braces and orthodontic care" },
  { src: "/services/Kids Dental Care.jpeg", alt: "Gentle dental care for children" },
  { src: "/services/Teeth Whitening.jpeg", alt: "Teeth whitening treatment" },
];

// --- DOCTORS ---------------------------------------------------------------
// ⚠ INTENTIONALLY EMPTY. No doctor names, degrees, or experience are invented.
// Add real entries and the Doctors page + cards populate automatically:
//   { name, title, department, specialization, experience, image }
export const doctors = [];

// --- TESTIMONIALS ----------------------------------------------------------
// ⚠ INTENTIONALLY EMPTY. The reviews in the original project used inconsistent
// names and appear to be placeholders, so they are not shown. Add genuine,
// consented patient reviews here to enable the Testimonials section:
//   { name, rating, review, location }
export const testimonials = [];

// --- TRUST BADGES (honest, non-numeric — shown instead of invented stats) ---
export const trustBadges = [
  { icon: "tooth", label: "Complete Dental Care" },
  { icon: "shield", label: "Painless Treatment Focus" },
  { icon: "kids", label: "Gentle Care for Children" },
  { icon: "heart", label: "Patient-First Approach" },
];
