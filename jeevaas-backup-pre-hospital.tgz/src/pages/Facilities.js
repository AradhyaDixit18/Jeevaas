import SEO from "../components/SEO";
import PageHeader from "../components/PageHeader";
import Reveal from "../components/Reveal";
import Icon from "../components/Icon";
import CTABand from "../components/CTABand";
import { facilities, gallery } from "../data/content";

export default function Facilities() {
  return (
    <>
      <SEO
        title="Facilities"
        description="A clean, modern, child-friendly dental facility in Kalyanpur, Kanpur with strict sterilisation and digital dentistry."
        path="/facilities"
      />
      <PageHeader
        eyebrow="Our facility"
        title="A clean, modern, welcoming clinic"
        intro="Thoughtfully designed spaces and up-to-date equipment, built around your comfort and safety."
      />

      <section className="container-x py-16 sm:py-20">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {facilities.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.05}>
              <div className="card h-full p-7">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-100 text-teal-600">
                  <Icon name={f.icon} className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-lg font-bold text-ink-900">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-600">{f.text}</p>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Visual strip from available imagery */}
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {gallery.slice(0, 6).map((g, i) => (
            <Reveal key={g.src} delay={i * 0.04}>
              <div className="group overflow-hidden rounded-3xl">
                <img
                  src={g.src}
                  alt={g.alt}
                  loading="lazy"
                  className="h-56 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <CTABand />
    </>
  );
}
