import { Link } from "react-router-dom";
import SEO from "../components/SEO";
import Icon from "../components/Icon";
import Reveal from "../components/Reveal";
import SectionHeading from "../components/SectionHeading";
import ServiceCard from "../components/ServiceCard";
import CTABand from "../components/CTABand";
import { site, links } from "../config/site";
import {
  services,
  whyChooseUs,
  healthTips,
  trustBadges,
  testimonials,
} from "../data/content";

const quickActions = [
  { label: "Book Appointment", to: "/book", icon: "calendar", primary: true },
  { label: "Find a Doctor", to: "/doctors", icon: "userMd" },
  { label: "Our Services", to: "/services", icon: "tooth" },
  { label: "Contact Us", to: "/contact", icon: "pin" },
];

export default function Home() {
  return (
    <>
      <SEO
        title="Dental Care in Kalyanpur, Kanpur"
        description={site.description}
        path="/"
      />

      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/hero-bg.jpeg"
            alt=""
            aria-hidden="true"
            className="h-full w-full object-cover"
          />
          {/* True gradient scrim (not stacked bands) */}
          <div className="absolute inset-0 bg-gradient-to-r from-ink-950/95 via-ink-950/80 to-ink-900/40" />
        </div>

        <div className="container-x relative grid gap-10 py-20 sm:py-24 lg:grid-cols-12 lg:py-28">
          <div className="lg:col-span-7">
            <Reveal>
              <span className="eyebrow text-teal-300">
                <span className="h-2 w-2 rounded-sm bg-teal-400" /> Advanced Dental Care
              </span>
            </Reveal>
            <Reveal delay={0.05}>
              <h1 className="mt-4 text-4xl font-extrabold leading-[1.08] text-white sm:text-5xl lg:text-6xl">
                Healthy Smiles for a{" "}
                <span className="bg-gradient-to-r from-brand-300 to-teal-300 bg-clip-text text-transparent">
                  Better Life
                </span>
              </h1>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-100">
                Complete, painless dental care with modern technology at {site.name},
                Kalyanpur, Kanpur. Gentle treatment for the whole family, from routine
                cleaning to implants, braces, and care for children.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link to="/book" className="btn-primary btn-lg">
                  <Icon name="calendar" className="h-4 w-4" /> Book Appointment
                </Link>
                <a href={links.call} className="btn-outline-white btn-lg">
                  <Icon name="phone" className="h-4 w-4" /> Call {site.phone.display}
                </a>
              </div>
            </Reveal>

            {/* Floating trust indicators (honest, non-numeric) */}
            <Reveal delay={0.2}>
              <ul className="mt-10 grid max-w-xl grid-cols-2 gap-3 sm:grid-cols-4">
                {trustBadges.map((b) => (
                  <li
                    key={b.label}
                    className="flex flex-col items-center gap-2 rounded-2xl bg-white/10 p-3 text-center backdrop-blur-sm ring-1 ring-white/15"
                  >
                    <Icon name={b.icon} className="h-5 w-5 text-teal-300" />
                    <span className="text-xs font-semibold text-white">{b.label}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ================= QUICK ACTIONS ================= */}
      <section className="container-x -mt-10 relative z-10">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((a) => (
            <Link
              key={a.label}
              to={a.to}
              className={`card card-hover flex items-center gap-3 p-5 ${
                a.primary ? "ring-brand-200" : ""
              }`}
            >
              <span
                className={`inline-flex h-11 w-11 items-center justify-center rounded-2xl ${
                  a.primary ? "bg-brand-600 text-white" : "bg-brand-50 text-brand-600"
                }`}
              >
                <Icon name={a.icon} className="h-5 w-5" />
              </span>
              <span className="font-semibold text-ink-900">{a.label}</span>
              <Icon name="arrow" className="ml-auto h-4 w-4 text-ink-300" />
            </Link>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap gap-3">
          <a href={links.call} className="btn-ghost btn-md flex-1 sm:flex-none">
            <Icon name="phone" className="h-4 w-4 text-brand-600" /> Call Now
          </a>
          <a
            href={links.whatsapp}
            target="_blank"
            rel="noreferrer"
            className="btn-ghost btn-md flex-1 sm:flex-none"
          >
            <Icon name="whatsapp" className="h-4 w-4 text-teal-600" /> WhatsApp
          </a>
        </div>
      </section>

      {/* ================= SERVICES ================= */}
      <section className="container-x py-16 sm:py-20">
        <SectionHeading
          eyebrow="What we do"
          title="Complete dental care, under one roof"
          intro="From everyday check-ups to advanced treatments, our services are designed to keep your whole family smiling."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.slug} delay={i * 0.05}>
              <ServiceCard service={s} />
            </Reveal>
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link to="/services" className="btn-ghost btn-lg">
            View all services <Icon name="arrow" className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* ================= WHY CHOOSE US ================= */}
      <section className="bg-brand-50/50 py-16 sm:py-20">
        <div className="container-x">
          <SectionHeading
            eyebrow="Why Jeevaas"
            title="Care you can trust, comfort you can feel"
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {whyChooseUs.map((w, i) => (
              <Reveal key={w.title} delay={i * 0.05}>
                <div className="card h-full p-7">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-100 text-teal-600">
                    <Icon name={w.icon} className="h-6 w-6" />
                  </span>
                  <h3 className="mt-5 text-lg font-bold text-ink-900">{w.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-600">{w.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ================= KIDS TEASER ================= */}
      <section className="container-x py-16 sm:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <Reveal>
            <div className="relative overflow-hidden rounded-3xl">
              <img
                src="/services/Kids Dental Care.jpeg"
                alt="Gentle dental care for children"
                loading="lazy"
                className="h-72 w-full object-cover sm:h-96"
              />
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <span className="eyebrow">
              <span className="h-2 w-2 rounded-sm bg-teal-500" /> For our youngest patients
            </span>
            <h2 className="mt-3 text-3xl font-bold text-ink-900 sm:text-4xl">
              Jeevaas Kids Health Zone
            </h2>
            <p className="mt-4 text-ink-600">
              A friendly, playful corner that helps children learn about their teeth and
              healthy habits through games and gentle guidance, so their first dental
              memories are happy ones.
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <Link to="/kids" className="btn-teal btn-lg">
                <Icon name="kids" className="h-4 w-4" /> Explore the Kids Zone
              </Link>
              <Link to="/services/kids-dental" className="btn-ghost btn-lg">
                Kids dental care
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ================= HEALTH TIPS TEASER ================= */}
      <section className="bg-ink-950 py-16 text-white sm:py-20">
        <div className="container-x">
          <SectionHeading
            eyebrow="Health & wellness"
            title="Small habits, healthy smiles"
            intro="Simple, everyday tips from our team to keep your family's teeth strong."
            light
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {healthTips.slice(0, 3).map((t, i) => (
              <Reveal key={t.title} delay={i * 0.05}>
                <div className="h-full rounded-3xl bg-white/5 p-7 ring-1 ring-white/10">
                  <Icon name={t.icon} className="h-7 w-7 text-teal-300" />
                  <h3 className="mt-4 text-lg font-bold text-white">{t.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-200">{t.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link to="/health-wellness" className="btn-outline-white btn-lg">
              More health tips <Icon name="arrow" className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ================= TESTIMONIALS (only when real ones exist) ======== */}
      {testimonials.length > 0 && (
        <section className="container-x py-16 sm:py-20">
          <SectionHeading eyebrow="Patient stories" title="What our patients say" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {testimonials.map((t, i) => (
              <Reveal key={i} delay={i * 0.05}>
                <figure className="card h-full p-7">
                  <div className="flex gap-0.5 text-warm-500">
                    {Array.from({ length: t.rating || 5 }).map((_, j) => (
                      <Icon key={j} name="star" className="h-4 w-4" />
                    ))}
                  </div>
                  <blockquote className="mt-4 text-ink-700">"{t.review}"</blockquote>
                  <figcaption className="mt-4 font-semibold text-ink-900">
                    {t.name}
                    {t.location && (
                      <span className="font-normal text-ink-500"> · {t.location}</span>
                    )}
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </section>
      )}

      <CTABand />
    </>
  );
}
