import SEO from "../components/SEO";
import PageHeader from "../components/PageHeader";
import Reveal from "../components/Reveal";
import Icon from "../components/Icon";
import CTABand from "../components/CTABand";
import { site } from "../config/site";
import { whyChooseUs } from "../data/content";

const values = [
  { icon: "heart", title: "Patient First", text: "Every plan starts with your comfort, your goals, and honest advice." },
  { icon: "shield", title: "Safety & Hygiene", text: "Careful sterilisation and infection control on every single visit." },
  { icon: "sparkle", title: "Elevated Care", text: "Modern techniques and equipment for precise, comfortable treatment." },
  { icon: "userMd", title: "One Trusted Team", text: "Continuity of care from a team that knows you and your family." },
];

export default function About() {
  return (
    <>
      <SEO
        title="About Us"
        description={`Learn about ${site.name}, a modern dental care centre in Kalyanpur, Kanpur focused on painless, patient-first treatment.`}
        path="/about"
      />
      <PageHeader
        eyebrow="About Jeevaas"
        title="A modern dental home for your family"
        intro={`${site.name} brings together caring people and modern dentistry in the heart of Kalyanpur, Kanpur.`}
      />

      <section className="container-x py-16 sm:py-20">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <img
              src="/doctor_team.jpeg"
              alt="The dental care team at Jeevaas Hospital"
              loading="lazy"
              className="w-full rounded-3xl object-cover shadow-card"
            />
          </Reveal>
          <Reveal delay={0.1}>
            <span className="eyebrow">
              <span className="h-2 w-2 rounded-sm bg-teal-500" /> Our story
            </span>
            <h2 className="mt-3 text-3xl font-bold text-ink-900">
              Dentistry that feels calm, clear, and caring
            </h2>
            <p className="mt-4 text-ink-600">
              {site.name} was built on a simple idea: dental care should never be
              something to fear. From the moment you arrive, our focus is on making
              treatment gentle, explaining every step in plain language, and giving
              you the information you need to make confident decisions about your care.
            </p>
            <p className="mt-4 text-ink-600">
              We care for the whole family, from a child's very first visit to advanced
              treatments for adults, all under one roof in Kalyanpur, Kanpur.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Mission / Vision */}
      <section className="bg-brand-50/50 py-16 sm:py-20">
        <div className="container-x grid gap-6 md:grid-cols-2">
          <Reveal>
            <div className="card h-full p-8">
              <Icon name="heart" className="h-8 w-8 text-brand-600" />
              <h3 className="mt-4 text-xl font-bold text-ink-900">Our Mission</h3>
              <p className="mt-3 text-ink-600">
                To provide painless, high-quality dental care that puts patients first,
                and to help every person who walks through our doors keep a healthy,
                confident smile for life.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="card h-full p-8">
              <Icon name="sparkle" className="h-8 w-8 text-teal-600" />
              <h3 className="mt-4 text-xl font-bold text-ink-900">Our Vision</h3>
              <p className="mt-3 text-ink-600">
                To be Kanpur's most trusted dental home, known for gentle care,
                honest advice, and a warm, family-friendly experience for patients
                of every age.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Values */}
      <section className="container-x py-16 sm:py-20">
        <div className="max-w-2xl">
          <span className="eyebrow">
            <span className="h-2 w-2 rounded-sm bg-teal-500" /> What we stand for
          </span>
          <h2 className="mt-3 text-3xl font-bold text-ink-900">Our values</h2>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v, i) => (
            <Reveal key={v.title} delay={i * 0.05}>
              <div className="card h-full p-7">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
                  <Icon name={v.icon} className="h-6 w-6" />
                </span>
                <h3 className="mt-5 text-lg font-bold text-ink-900">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-600">{v.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Why choose us reused */}
      <section className="bg-ink-950 py-16 text-white sm:py-20">
        <div className="container-x">
          <div className="max-w-2xl">
            <span className="eyebrow text-teal-300">
              <span className="h-2 w-2 rounded-sm bg-teal-400" /> The Jeevaas difference
            </span>
            <h2 className="mt-3 text-3xl font-bold text-white">
              Reasons families choose us
            </h2>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {whyChooseUs.map((w, i) => (
              <Reveal key={w.title} delay={i * 0.05}>
                <div className="h-full rounded-3xl bg-white/5 p-7 ring-1 ring-white/10">
                  <Icon name={w.icon} className="h-7 w-7 text-teal-300" />
                  <h3 className="mt-4 text-lg font-bold text-white">{w.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-200">{w.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CTABand />
    </>
  );
}
