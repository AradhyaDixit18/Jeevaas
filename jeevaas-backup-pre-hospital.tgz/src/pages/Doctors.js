import { Link } from "react-router-dom";
import SEO from "../components/SEO";
import PageHeader from "../components/PageHeader";
import Reveal from "../components/Reveal";
import Icon from "../components/Icon";
import CTABand from "../components/CTABand";
import { doctors } from "../data/content";
import { site, links } from "../config/site";

export default function Doctors() {
  return (
    <>
      <SEO
        title="Our Doctors"
        description={`Meet the dental care team at ${site.name} in Kalyanpur, Kanpur.`}
        path="/doctors"
      />
      <PageHeader
        eyebrow="Our team"
        title="Meet the people behind your smile"
        intro="Caring, qualified professionals dedicated to gentle, high-quality dental care."
      />

      <section className="container-x py-16 sm:py-20">
        {doctors.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {doctors.map((d, i) => (
              <Reveal key={d.name} delay={i * 0.05}>
                <article className="card card-hover h-full overflow-hidden">
                  <img
                    src={d.image || "/doctor_team.jpeg"}
                    alt={d.name}
                    loading="lazy"
                    className="h-64 w-full object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-lg font-bold text-ink-900">{d.name}</h3>
                    {d.title && <p className="text-sm font-semibold text-brand-700">{d.title}</p>}
                    {d.department && <p className="mt-1 text-sm text-ink-500">{d.department}</p>}
                    {d.specialization && (
                      <p className="mt-3 text-sm text-ink-600">{d.specialization}</p>
                    )}
                    {d.experience && (
                      <p className="mt-2 text-xs font-semibold text-teal-600">{d.experience}</p>
                    )}
                    <Link
                      to={`/book?doctor=${encodeURIComponent(d.name)}`}
                      className="btn-teal btn-md mt-5 w-full"
                    >
                      Book with {d.name.split(" ")[0]}
                    </Link>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        ) : (
          // Honest empty state — no invented doctors.
          <Reveal>
            <div className="mx-auto max-w-2xl rounded-3xl bg-brand-50/60 p-10 text-center ring-1 ring-brand-100">
              <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white text-brand-600 shadow-soft">
                <Icon name="userMd" className="h-8 w-8" />
              </span>
              <h2 className="mt-6 text-2xl font-bold text-ink-900">
                Team profiles coming soon
              </h2>
              <p className="mx-auto mt-3 max-w-md text-ink-600">
                We're preparing detailed profiles of our dental team. In the meantime,
                our staff will be glad to help you and answer any questions when you book.
              </p>
              <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
                <Link to="/book" className="btn-primary btn-lg">
                  <Icon name="calendar" className="h-4 w-4" /> Book Appointment
                </Link>
                <a href={links.call} className="btn-ghost btn-lg">
                  <Icon name="phone" className="h-4 w-4 text-brand-600" /> Call {site.phone.display}
                </a>
              </div>
            </div>
          </Reveal>
        )}
      </section>

      <CTABand />
    </>
  );
}
