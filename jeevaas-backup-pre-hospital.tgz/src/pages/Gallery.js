import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FaTimes } from "react-icons/fa";
import SEO from "../components/SEO";
import PageHeader from "../components/PageHeader";
import Reveal from "../components/Reveal";
import CTABand from "../components/CTABand";
import { gallery } from "../data/content";

export default function Gallery() {
  const [active, setActive] = useState(null);

  return (
    <>
      <SEO
        title="Gallery"
        description="A look inside Jeevaas Hospital and the dental treatments we provide in Kalyanpur, Kanpur."
        path="/gallery"
      />
      <PageHeader
        eyebrow="Gallery"
        title="A look at our care"
        intro="Images of our treatments and services. Clinic photos will be added here over time."
      />

      <section className="container-x py-16 sm:py-20">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {gallery.map((g, i) => (
            <Reveal key={g.src} delay={i * 0.04}>
              <button
                onClick={() => setActive(g)}
                className="group block w-full overflow-hidden rounded-3xl focus-visible:ring-2 focus-visible:ring-brand-500"
                aria-label={`View larger: ${g.alt}`}
              >
                <img
                  src={g.src}
                  alt={g.alt}
                  loading="lazy"
                  className="h-60 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </button>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-[60] flex items-center justify-center bg-ink-950/90 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            role="dialog"
            aria-modal="true"
            aria-label={active.alt}
          >
            <button
              className="absolute right-5 top-5 inline-flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white ring-1 ring-white/30"
              onClick={() => setActive(null)}
              aria-label="Close"
            >
              <FaTimes className="h-5 w-5" />
            </button>
            <motion.img
              key={active.src}
              src={active.src}
              alt={active.alt}
              initial={{ scale: 0.92 }}
              animate={{ scale: 1 }}
              className="max-h-[85vh] max-w-full rounded-2xl object-contain shadow-lift"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <CTABand />
    </>
  );
}
