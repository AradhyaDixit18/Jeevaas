import { useParams, Link, Navigate } from "react-router-dom";
import SEO from "../components/SEO";
import PageHeader from "../components/PageHeader";
import Reveal from "../components/Reveal";
import Icon from "../components/Icon";
import CTABand from "../components/CTABand";
import { getService, services } from "../data/content";
import { site } from "../config/site";

export default function ServiceDetail() {
  const { slug } = useParams();
  const service = getService(slug);

  if (!service) return <Navigate to="/services" replace />;

  const others = services.filter((s) => s.slug !== slug).slice(0, 3);

  const schema = {
    "@context": "https://schema.org",
    "@type": "MedicalProcedure",
    name: service.title,
    description: service.overview,
    url: `${site.url}/services/${service.slug}`,
    provider: { "@type": "Dentist", name: site.name },
  };

  return (
    <>
      <SEO
        title={service.title}
        description={service.short}
        path={`/services/${service.slug}`}
        image={service.image}
        schema={schema}
      />
      <PageHeader eyebrow="Service" title={service.title} intro={service.short} crumb={service.title} />

      <section className="container-x py-16 sm:py-20">
        <div className="grid gap-12 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <Reveal>
              <img
                src={service.image}
                alt={service.title}
                className="mb-8 h-72 w-full rounded-3xl object-cover shadow-card sm:h-96"
              />
            </Reveal>
            <Reveal delay={0.05}>
              <h2 className="text-2xl font-bold text-ink-900">Overview</h2>
              <p className="mt-3 text-ink-600">{service.overview}</p>

              <h3 className="mt-8 text-xl font-bold text-ink-900">What to expect</h3>
              <ul className="mt-4 space-y-3">
                {service.points.map((p) => (
                  <li key={p} className="flex gap-3 text-ink-700">
                    <Icon name="check" className="mt-1 h-5 w-5 shrink-0 text-teal-500" />
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-2">
            <Reveal delay={0.1}>
              <div className="card sticky top-24 p-7">
                <h3 className="text-lg font-bold text-ink-900">Is this for me?</h3>
                <p className="mt-2 text-sm text-ink-600">{service.good_for}</p>
                <div className="mt-6 space-y-3">
                  <Link to={`/book?service=${service.slug}`} className="btn-primary btn-lg w-full">
                    <Icon name="calendar" className="h-4 w-4" /> Book this treatment
                  </Link>
                  <Link to="/contact" className="btn-ghost btn-md w-full">
                    Ask a question
                  </Link>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Related */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-ink-900">Other treatments</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            {others.map((o) => (
              <Link key={o.slug} to={`/services/${o.slug}`} className="card card-hover flex items-center gap-3 p-5">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
                  <Icon name={o.icon} className="h-5 w-5" />
                </span>
                <span className="font-semibold text-ink-900">{o.title}</span>
                <Icon name="arrow" className="ml-auto h-4 w-4 text-ink-300" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CTABand />
    </>
  );
}
