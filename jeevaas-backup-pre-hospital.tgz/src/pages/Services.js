import SEO from "../components/SEO";
import PageHeader from "../components/PageHeader";
import Reveal from "../components/Reveal";
import ServiceCard from "../components/ServiceCard";
import CTABand from "../components/CTABand";
import { services } from "../data/content";
import { site } from "../config/site";

export default function Services() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: services.map((s, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: s.title,
      url: `${site.url}/services/${s.slug}`,
    })),
  };

  return (
    <>
      <SEO
        title="Our Services"
        description="Explore dental services at Jeevaas Hospital: root canals, dental implants, teeth cleaning, braces and aligners, kids dental care, and teeth whitening."
        path="/services"
        schema={schema}
      />
      <PageHeader
        eyebrow="Our services"
        title="Dental treatments for every need"
        intro="Comprehensive, gentle care for the whole family. Choose a treatment to learn more, or book directly."
      />
      <section className="container-x py-16 sm:py-20">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.slug} delay={i * 0.05}>
              <ServiceCard service={s} />
            </Reveal>
          ))}
        </div>
      </section>
      <CTABand />
    </>
  );
}
