import { Link } from "react-router-dom";
import Icon from "./Icon";

/** Reusable service/department card with hover lift and dual CTA. */
export default function ServiceCard({ service }) {
  return (
    <article className="card card-hover group flex h-full flex-col overflow-hidden">
      <div className="relative h-44 overflow-hidden">
        <img
          src={service.image}
          alt={service.title}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-900/40 to-transparent" />
        <span className="absolute left-4 top-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-white/95 text-brand-600 shadow-soft">
          <Icon name={service.icon} className="h-5 w-5" />
        </span>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <h3 className="text-lg font-bold text-ink-900">{service.title}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-600">
          {service.short}
        </p>
        <div className="mt-5 flex items-center justify-between gap-3">
          <Link to={`/services/${service.slug}`} className="link-underline text-sm">
            Learn more <Icon name="arrow" className="h-3 w-3" />
          </Link>
          <Link
            to={`/book?service=${service.slug}`}
            className="btn-teal btn-md"
            aria-label={`Book an appointment for ${service.title}`}
          >
            Book
          </Link>
        </div>
      </div>
    </article>
  );
}
