/** Primary navigation — edit once, updates navbar, mobile menu, and footer. */
export const nav = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Doctors", to: "/doctors" },
  { label: "Facilities", to: "/facilities" },
  { label: "Kids Zone", to: "/kids" },
  { label: "Health Tips", to: "/health-wellness" },
  { label: "Patient Resources", to: "/patient-resources" },
  { label: "Gallery", to: "/gallery" },
  { label: "Contact", to: "/contact" },
];

// A trimmed set for the top navbar (the rest live under "More" / mobile menu)
export const primaryNav = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Doctors", to: "/doctors" },
  { label: "Kids Zone", to: "/kids" },
  { label: "Contact", to: "/contact" },
];

export const footerQuickLinks = [
  { label: "About Us", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Doctors", to: "/doctors" },
  { label: "Facilities", to: "/facilities" },
  { label: "Health Tips", to: "/health-wellness" },
  { label: "Patient Resources", to: "/patient-resources" },
  { label: "Gallery", to: "/gallery" },
  { label: "Contact", to: "/contact" },
];

export const footerLegalLinks = [
  { label: "Privacy Policy", to: "/privacy" },
  { label: "Terms of Use", to: "/terms" },
  { label: "Accessibility", to: "/accessibility" },
];

export default nav;
