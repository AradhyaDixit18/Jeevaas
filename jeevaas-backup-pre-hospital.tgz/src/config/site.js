/**
 * ============================================================================
 *  JEEVAAS HOSPITAL — CENTRAL SITE CONFIGURATION
 * ============================================================================
 *  This is the ONE place to edit hospital information. Every component reads
 *  from here. Do not hard-code contact details, links, or content anywhere
 *  else in the codebase.
 *
 *  Fields marked  // ⚠ CONFIRM  hold values that were inconsistent or missing
 *  in the original project. Update them with the correct value and the whole
 *  site updates automatically.
 * ============================================================================
 */

export const site = {
  name: "Jeevaas Hospital",
  legalName: "Jeevaas Hospital Private Limited",
  shortName: "Jeevaas",
  // The practice is a dental care centre.
  discipline: "Dental Care",
  tagline: "Healthy Smiles for a Better Life",
  description:
    "Jeevaas Hospital is a modern dental care centre in Kalyanpur, Kanpur, offering painless, patient-first treatment with advanced technology — from routine cleaning to implants, braces, and gentle care for children.",
  url: "https://www.jeevaashospital.com", // ⚠ CONFIRM production domain
  logo: "/logo.png",

  // --- CONTACT -------------------------------------------------------------
  // ⚠ CONFIRM: the original code used THREE different numbers.
  //   9653090717  → on "Call Now" buttons   (assumed PRIMARY line below)
  //   9451951974  → on all WhatsApp links    (assumed WhatsApp below)
  //   7307629938  → listed in Location.js as phone + WhatsApp
  // Set the correct values here and every button/link updates.
  phone: {
    display: "+91 96530 90717",
    tel: "+919653090717",
  },
  whatsapp: {
    // digits only, international format, no "+"
    number: "919451951974",
    defaultMessage:
      "Hello Jeevaas Hospital, I would like to book a dental consultation.",
  },
  email: "admin@jeevaashospital.com",

  address: {
    line1: "G C, 45/1, Awas Vikas, Keshavpuram",
    line2: "Kalyanpur, Kanpur",
    city: "Kanpur",
    state: "Uttar Pradesh",
    postalCode: "208017",
    country: "India",
    full:
      "G C, 45/1, Awas Vikas, Keshavpuram, Kalyanpur, Kanpur, Uttar Pradesh 208017",
  },

  geo: { lat: 26.5096, lng: 80.2793 },

  // Google Maps: uses the coordinates + name for an embed and a directions link.
  map: {
    // Embeddable query (place name + address). No API key required for this embed.
    embedQuery:
      "Jeevaas Hospital Private Limited, Awas Vikas, Keshavpuram, Kalyanpur, Kanpur, Uttar Pradesh 208017",
    directionsUrl:
      "https://www.google.com/maps/dir/?api=1&destination=26.5096,80.2793",
  },

  // --- HOURS  ⚠ CONFIRM (not present in original project) ------------------
  hours: [
    { day: "Monday – Saturday", time: "10:00 AM – 8:00 PM" },
    { day: "Sunday", time: "By appointment" },
  ],
  hoursConfirmed: false, // set true once verified so the "hours to be confirmed" note hides
  emergencyNote:
    "For urgent dental pain outside opening hours, call the clinic line and follow the voicemail instructions.",

  // --- SOCIAL --------------------------------------------------------------
  // Only links with a real URL are rendered. Leave a url empty ("") to hide it.
  social: {
    instagram: "https://instagram.com/jeevaas_hospital", // confirmed in repo
    facebook: "", // ⚠ add when known
    youtube: "", // ⚠ add when known
    linkedin: "", // ⚠ add when known
  },
};

// Convenience derived links -------------------------------------------------
export const links = {
  call: `tel:${site.phone.tel}`,
  whatsapp: `https://wa.me/${site.whatsapp.number}?text=${encodeURIComponent(
    site.whatsapp.defaultMessage
  )}`,
  email: `mailto:${site.email}`,
  mapsEmbed: `https://www.google.com/maps?q=${encodeURIComponent(
    site.map.embedQuery
  )}&output=embed`,
  directions: site.map.directionsUrl,
};

export default site;
