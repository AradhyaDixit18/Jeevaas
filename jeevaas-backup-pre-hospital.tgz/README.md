# Jeevaas Hospital — Website (v2)

A modern, responsive, accessible website for **Jeevaas Hospital Private Limited**, a
dental care centre in Kalyanpur, Kanpur. Built with React, React Router, Tailwind CSS,
Framer Motion, and EmailJS.

## Tech stack

- **React 18** (Create React App / react-scripts)
- **React Router v6** — multi-page routing
- **Tailwind CSS v3** — design system
- **Framer Motion** — animation (respects `prefers-reduced-motion`)
- **react-helmet-async** — per-page SEO / meta / structured data
- **@emailjs/browser** — appointment + contact form delivery

## Getting started

```bash
npm install
cp .env.example .env      # optional; sensible defaults are built in
npm start                 # dev server at http://localhost:3000
npm run build             # production build into /build
```

## Configuration — edit ONE place

- `src/config/site.js` — hospital name, phone, WhatsApp, email, address, hours,
  social links, map. **Fields marked `⚠ CONFIRM` need verification.**
- `src/config/nav.js` — navigation structure.
- `src/config/emailjs.js` — EmailJS IDs (with env-var overrides).
- `src/data/content.js` — services, FAQs, resources, health tips, gallery,
  **doctors (empty)**, **testimonials (empty)**.
- `src/data/kids.js` — Kids Zone content.

## EmailJS

Appointment + contact submissions are sent via EmailJS to
`admin@jeevaashospital.com`. Only the **public key** is used client-side (safe to
expose). Never put a private key in the frontend.

Template variables sent: `patient_name, phone, email, age, department, doctor,
appointment_date, appointment_time, appointment_type, message, submitted_at,
reference, reply_to`.

A patient auto-reply is architected but disabled. To enable it, create a second
EmailJS template addressed to `{{email}}` and set
`REACT_APP_EMAILJS_AUTOREPLY_TEMPLATE_ID`.

## Deploy (Vercel)

Framework preset: **Create React App**. Build command `npm run build`, output `build`.
`vercel.json` rewrites all routes to `index.html` for client-side routing. Set the
EmailJS env vars in Project Settings if you want to override the built-in defaults.

## Notes

- Doctors and testimonials are intentionally empty until real, verified data is
  supplied. The UI populates automatically once entries are added.
- Replace `/public` images with optimized versions for best performance.
